function bit(p)
  return 2^(p-1)
end
