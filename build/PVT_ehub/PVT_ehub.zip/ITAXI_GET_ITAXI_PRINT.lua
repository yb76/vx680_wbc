function get_itaxi_print()
  return taxicfg.header,taxicfg.mtrailer,taxicfg.ctrailer
end
